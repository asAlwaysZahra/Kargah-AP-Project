package Main;

public enum AccountType {
    PRIVATE, PUBLIC
}